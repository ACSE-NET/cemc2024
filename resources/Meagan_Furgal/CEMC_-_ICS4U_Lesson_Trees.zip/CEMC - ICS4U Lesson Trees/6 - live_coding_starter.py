class Node:
    def __init__(self, value):

    def addChild(self, value):

    def findChild(self, value):

    def removeChild(self, value):


class Tree:
    def __init__(self, value):









